# A Heap-Based Stack Calculator

To compile, type:

    make

To run, type:

    ./calc

To run with `valgrind`, type:

    make valgrind

To run with `valgrind` with the input in `input.txt`:

    make quickgrind

To debug with GDB (with the input from `input.txt` and GDB script `gdb.script`):

    make debug
